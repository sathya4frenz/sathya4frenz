<script>
    function mult(a, b) { return (a * b);}
    console.log(mult(3,5));
</script>